<footer class="footer">
      <div>
        <span>&copy; 2019 Satsang Business Network all rights reserved. </span>
        <span><a href="#">Terms & Privacy</a></span>
      </div>     
    </footer>