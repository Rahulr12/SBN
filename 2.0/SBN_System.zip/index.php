<?
header("location: dashboard");
?>